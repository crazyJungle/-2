﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.DAL.Base;
using Model.ruanmou;
using DAL.ruanmou;

namespace ASP20170211
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string sUsername = TextUserName.Text.Trim();
                string sPwd = TextBoxPwd.Text.Trim();
                if(string.IsNullOrEmpty(sUsername) || string.IsNullOrEmpty(sPwd))
                {
                    Response.Write(@"<script>alert(""No Username or no Password..."");</script>");
                }
                else
                {
                    List<dbParam> listParams = new List<dbParam>();
                    listParams.Add(new dbParam() { ParamName="@UserName", ParamValue = sUsername });
                    listParams.Add(new dbParam() { ParamName="@Pwd", ParamValue = sPwd });
                    UserInfor user = UserInforDal.m_UserInforDal.GetModel("UserName=@UserName and Pwd=@Pwd", listParams, "UserId");
                    if (user == null)
                    {
                        Response.Write(@"<script>alert(""UserName or Password is Wrong!"");</script>");
                    }
                    else
                    {
                        Response.Redirect("UserM.aspx");
                    }
                }
            }
            catch 
            {
                Response.Write(@"<script>alert(""The WebSite is under repairing..."");</script>");
            }
           
        }
    }
}