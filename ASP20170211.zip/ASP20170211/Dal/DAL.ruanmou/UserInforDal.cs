﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.DAL.Base;
using Model.ruanmou;
using com.Utility;
using System.Web;
namespace DAL.ruanmou
{
    public class UserInforDal : System.Web.UI.Page
    {
        //静态类:只要用这个对象就可以使用BaseDAL的方法.
        public static BaseDAL<UserInfor> m_UserInforDal = new BaseDAL<UserInfor>();
    }
}
