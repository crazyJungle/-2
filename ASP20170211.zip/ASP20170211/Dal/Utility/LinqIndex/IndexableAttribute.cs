﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace com.Utility
{
    public class IndexableAttribute : Attribute
    {

    }
}
