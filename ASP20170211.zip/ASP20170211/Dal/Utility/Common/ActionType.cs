﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.jk39.Utility
{
    public enum ActionType
    {
        Add,
        Modi,
        Delete,
        Query,
        Audi,
        None
    }
}
